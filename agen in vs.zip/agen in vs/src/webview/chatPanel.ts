import * as vscode from "vscode";
import { createAdapter } from "../llm/adapter";
import { Orchestrator } from "../agent/orchestrator";
import { allTools } from "../tools/index";

export function openChatPanel(context: vscode.ExtensionContext) {
  const panel = vscode.window.createWebviewPanel(
    "aiSoftwareEngineerChat",
    "AI Software Engineer",
    vscode.ViewColumn.Beside,
    { enableScripts: true }
  );

  panel.webview.html = getHtml();

  panel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type !== "ask" || !msg.text) {
      return;
    }

    try {
      const orchestrator = new Orchestrator(createAdapter(), allTools);
      const result = await orchestrator.run(msg.text);

      panel.webview.postMessage({
        type: "reply",
        text: result.reply,
        meta: `tools: ${result.toolsUsed.join(", ") || "none"} | iterations: ${result.iterations}`,
      });
    } catch (e: any) {
      panel.webview.postMessage({
        type: "reply",
        text: `Error: ${e?.message ?? String(e)}`,
        meta: "",
      });
    }
  });
}

function getHtml(): string {
  return /* html */ `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Software Engineer</title>
  <style>
    body {
      font-family: var(--vscode-font-family);
      color: var(--vscode-foreground);
      background: var(--vscode-editor-background);
      margin: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }
    #chat {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
    }
    .bubble {
      max-width: 85%;
      padding: 8px 12px;
      margin: 6px 0;
      border-radius: 8px;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .user {
      background: var(--vscode-button-background);
      color: var(--vscode-button-foreground);
      margin-left: auto;
    }
    .bot {
      background: var(--vscode-editorWidget-background);
      border: 1px solid var(--vscode-editorWidget-border);
    }
    .meta {
      font-size: 11px;
      opacity: 0.6;
      margin-top: 4px;
    }
    #bar {
      display: flex;
      gap: 8px;
      padding: 10px;
      border-top: 1px solid var(--vscode-panel-border);
    }
    #input {
      flex: 1;
      background: var(--vscode-input-background);
      color: var(--vscode-input-foreground);
      border: 1px solid var(--vscode-input-border);
      padding: 8px;
      border-radius: 4px;
    }
    #send {
      background: var(--vscode-button-background);
      color: var(--vscode-button-foreground);
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
    }
    #send:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  </style>
</head>
<body>
  <div id="chat">
    <div class="bubble bot">Ask me to analyse your workspace, find bugs or explain errors.</div>
  </div>
  <div id="bar">
    <input id="input" type="text" placeholder="e.g. find bugs in src/tools/context.ts" />
    <button id="send">Send</button>
  </div>

  <script>
    const vscode = acquireVsCodeApi();
    const chat = document.getElementById("chat");
    const input = document.getElementById("input");
    const send = document.getElementById("send");

    function addBubble(text, who, meta) {
      const div = document.createElement("div");
      div.className = "bubble " + who;
      div.textContent = text;
      if (meta) {
        const m = document.createElement("div");
        m.className = "meta";
        m.textContent = meta;
        div.appendChild(m);
      }
      chat.appendChild(div);
      chat.scrollTop = chat.scrollHeight;
    }

    function submit() {
      const text = input.value.trim();
      if (!text) return;
      addBubble(text, "user");
      input.value = "";
      send.disabled = true;
      addBubble("Thinking...", "bot", "");
      vscode.postMessage({ type: "ask", text });
    }

    send.addEventListener("click", submit);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
    });

    window.addEventListener("message", (event) => {
      const msg = event.data;
      if (msg.type === "reply") {
        chat.removeChild(chat.lastChild);
        addBubble(msg.text, "bot", msg.meta);
        send.disabled = false;
        input.focus();
      }
    });
  </script>
</body>
</html>`;
}