import * as vscode from "vscode";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { getConfig } from "../config";
import { allTools } from "../tools/index";
import { AgentTool } from "../tools/context";

const connected: Client[] = [];

function textOf(result: any): string {
  const content = result?.content;
  if (!Array.isArray(content)) {
    return JSON.stringify(result ?? null);
  }
  const parts = content
    .filter((c: any) => c?.type === "text")
    .map((c: any) => String(c.text ?? ""));
  const text = parts.join("\n");
  const header = result?.isError ? "MCP tool error:\n" : "";
  return header + (text || JSON.stringify(result));
}

export async function connectMcpServers(): Promise<void> {
  const servers = getConfig().mcpServers;

  for (const cfg of servers) {
    try {
      const transport = new StdioClientTransport({
        command: cfg.command,
        args: cfg.args ?? [],
        env: cfg.env,
      });

      const client = new Client({
        name: "ai-software-engineer",
        version: "0.0.1",
      });
      await client.connect(transport);
      connected.push(client);

      const listed = await client.listTools();

      for (const t of listed.tools ?? []) {
        const exposed: AgentTool = {
          name: `${cfg.name}_${t.name}`,
          description: `[MCP:${cfg.name}] ${t.description ?? ""}`.trim(),
          parameters: (t.inputSchema ?? {
            type: "object",
            properties: {},
          }) as Record<string, unknown>,
          async execute(args) {
            try {
              const res = await client.callTool({
                name: t.name,
                arguments: args,
              });
              return textOf(res);
            } catch (e: any) {
              return `Error calling MCP tool "${t.name}": ${
                e?.message ?? String(e)
              }`;
            }
          },
        };
        allTools.push(exposed);
      }
    } catch (e: any) {
      vscode.window.showWarningMessage(
        `MCP server "${cfg.name}" failed to connect: ${e?.message ?? String(e)}`
      );
    }
  }
}

export async function disconnectMcpServers(): Promise<void> {
  for (const client of connected.splice(0)) {
    try {
      await client.close();
    } catch {
      // ignore shutdown errors
    }
  }
}