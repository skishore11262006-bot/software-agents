import { LLMAdapter, LLMMessage, LLMToolSpec } from "../llm/types";
import { AgentTool } from "../tools/context";
import { getConfig } from "../config";
import { systemPrompt } from "./prompts";

export interface OrchestratorResult {
  reply: string;
  toolsUsed: string[];
  iterations: number;
}

export class Orchestrator {
  constructor(
    private adapter: LLMAdapter,
    private tools: AgentTool[]
  ) {}

  private toolSpecs(): LLMToolSpec[] {
    return this.tools.map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));
  }

  async run(userInput: string): Promise<OrchestratorResult> {
    const cfg = getConfig();
    const messages: LLMMessage[] = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userInput },
    ];
    const toolsUsed: string[] = [];

    for (let i = 0; i < cfg.maxIterations; i++) {
      const reply = await this.adapter.chat(messages, this.toolSpecs());
      messages.push(reply);

      if (!reply.tool_calls || reply.tool_calls.length === 0) {
        return {
          reply: reply.content,
          toolsUsed,
          iterations: i + 1,
        };
      }

      for (const call of reply.tool_calls) {
        const tool = this.tools.find((t) => t.name === call.function.name);
        let result: string;

        if (!tool) {
          result = `Error: unknown tool "${call.function.name}"`;
        } else {
          toolsUsed.push(call.function.name);
          try {
            const args = JSON.parse(call.function.arguments || "{}");
            result = await tool.execute(args);
          } catch (e: any) {
            result = `Error: ${e?.message ?? String(e)}`;
          }
        }

        messages.push({
          role: "tool",
          content: result,
          tool_call_id: call.id,
          name: call.function.name,
        });
      }
    }

    return {
      reply: "Stopped: reached max iterations without a final answer.",
      toolsUsed,
      iterations: cfg.maxIterations,
    };
  }
}