import * as vscode from "vscode";
import { saveApiKey } from "./config";
import { openChatPanel } from "./webview/chatPanel";
import { registerPatchProvider } from "./tools/patcher";
import { connectMcpServers, disconnectMcpServers } from "./mcp/client";

export function activate(context: vscode.ExtensionContext) {
  registerPatchProvider(context);

  connectMcpServers().catch((e) => {
    console.error("MCP connection failed:", e);
  });

  const helloCommand = vscode.commands.registerCommand(
    "ai-software-engineer.hello",
    () => {
      vscode.window.showInformationMessage(
        "AI Software Engineer: Step 1 skeleton works!"
      );
    }
  );

  const setApiKeyCommand = vscode.commands.registerCommand(
    "ai-software-engineer.setApiKey",
    () => saveApiKey(context)
  );

  const openChatCommand = vscode.commands.registerCommand(
    "ai-software-engineer.openChat",
    () => openChatPanel(context)
  );

  context.subscriptions.push(helloCommand, setApiKeyCommand, openChatCommand);
}

export async function deactivate(): Promise<void> {
  await disconnectMcpServers();
}