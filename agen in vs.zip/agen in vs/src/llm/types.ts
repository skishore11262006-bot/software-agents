export type Role = "system" | "user" | "assistant" | "tool";

export interface ToolCall {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
}

export interface LLMMessage {
  role: Role;
  content: string;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
  name?: string;
}

export interface LLMToolSpec {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface LLMAdapter {
  chat(messages: LLMMessage[], tools: LLMToolSpec[]): Promise<LLMMessage>;
}