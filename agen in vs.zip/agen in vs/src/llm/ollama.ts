import {
  LLMAdapter,
  LLMMessage,
  LLMToolSpec,
} from "./types";

export class OllamaAdapter implements LLMAdapter {
  constructor(
    private baseUrl: string,
    private model: string
  ) {}

  async chat(
    messages: LLMMessage[],
    tools: LLMToolSpec[]
  ): Promise<LLMMessage> {
    const body = {
      model: this.model,
      messages,
      tools: tools.length
        ? tools.map((t) => ({
            type: "function",
            function: {
              name: t.name,
              description: t.description,
              parameters: t.parameters,
            },
          }))
        : undefined,
      stream: false,
    };

    const res = await fetch(`${this.baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Ollama error ${res.status}: ${text}`);
    }

    const data: any = await res.json();
    const msg = data.message;

    return {
      role: "assistant",
      content: msg.content ?? "",
      tool_calls: msg.tool_calls?.map((tc: any, i: number) => ({
        id: `call_${Date.now()}_${i}`,
        type: "function" as const,
        function: {
          name: tc.function.name,
          arguments:
            typeof tc.function.arguments === "string"
              ? tc.function.arguments
              : JSON.stringify(tc.function.arguments),
        },
      })),
    };
  }
}