import { getConfig } from "../config";
import { LLMAdapter, LLMMessage, LLMToolSpec } from "./types";
import { OllamaAdapter } from "./ollama";

class OpenAIStub implements LLMAdapter {
  async chat(
    _messages: LLMMessage[],
    _tools: LLMToolSpec[]
  ): Promise<LLMMessage> {
    throw new Error(
      "OpenAI adapter not implemented yet - use provider 'ollama' for now"
    );
  }
}

class AnthropicStub extends OpenAIStub {}

export function createAdapter(): LLMAdapter {
  const cfg = getConfig();
  switch (cfg.provider) {
    case "ollama":
      return new OllamaAdapter(cfg.ollamaUrl, cfg.model);
    case "openai":
      return new OpenAIStub();
    case "anthropic":
      return new AnthropicStub();
  }
}