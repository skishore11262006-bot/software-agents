import * as vscode from "vscode";
import * as path from "path";
import { AgentTool } from "./context";

const SCHEME = "aiproposed";

class ProposedContentProvider implements vscode.TextDocumentContentProvider {
  private contents = new Map<string, string>();
  private emitter = new vscode.EventEmitter<vscode.Uri>();
  readonly onDidChange = this.emitter.event;

  set(uri: vscode.Uri, content: string): void {
    this.contents.set(uri.toString(), content);
    this.emitter.fire(uri);
  }

  provideTextDocumentContent(uri: vscode.Uri): string {
    return this.contents.get(uri.toString()) ?? "// proposal not found";
  }
}

let provider: ProposedContentProvider | undefined;

export function registerPatchProvider(
  context: vscode.ExtensionContext
): void {
  provider = new ProposedContentProvider();
  context.subscriptions.push(
    vscode.workspace.registerTextDocumentContentProvider(SCHEME, provider)
  );
}

export const proposeEditTool: AgentTool = {
  name: "propose_edit",
  description:
    "Propose a change to a file: replace exact oldText with newText. Opens a diff view and asks the user to approve. Changes are NEVER applied without approval.",
  parameters: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Relative file path, e.g. 'src/config.ts'",
      },
      oldText: {
        type: "string",
        description: "Exact existing text to replace (must appear exactly once)",
      },
      newText: {
        type: "string",
        description: "The replacement text (use '' to delete oldText)",
      },
    },
    required: ["path", "oldText", "newText"],
  },
  async execute(args) {
    if (!provider) {
      return "Error: patch provider not registered.";
    }

    const folder = vscode.workspace.workspaceFolders?.[0];
    if (!folder) {
      return "Error: no workspace folder is open.";
    }

    const root = folder.uri.fsPath;
    const resolved = path.resolve(root, String(args.path));
    if (resolved !== root && !resolved.startsWith(root + path.sep)) {
      return "Error: path is outside the workspace.";
    }

    const uri = vscode.Uri.file(resolved);
    let doc: vscode.TextDocument;
    try {
      doc = await vscode.workspace.openTextDocument(uri);
    } catch {
      return `Error: cannot open file "${args.path}".`;
    }

    const content = doc.getText();
    const oldText = String(args.oldText);
    const newText = String(args.newText);

    const first = content.indexOf(oldText);
    if (first === -1) {
      return "Error: oldText not found. Re-read the file and use exact text.";
    }
    const second = content.indexOf(oldText, first + 1);
    if (second !== -1) {
      return "Error: oldText appears more than once. Include more surrounding context to make it unique.";
    }

    const newContent =
      content.slice(0, first) +
      newText +
      content.slice(first + oldText.length);

    const proposedUri = vscode.Uri.parse(
      `${SCHEME}:/proposal-${Date.now()}-${path.basename(resolved)}`
    );
    provider.set(proposedUri, newContent);

    await vscode.commands.executeCommand(
      "vscode.diff",
      uri,
      proposedUri,
      `Proposed: ${vscode.workspace.asRelativePath(uri)}`
    );

    const choice = await vscode.window.showInformationMessage(
      `Apply this change to ${vscode.workspace.asRelativePath(uri)}?`,
      { modal: true },
      "Apply",
      "Reject"
    );

    if (choice !== "Apply") {
      return "User REJECTED the change. Do not propose the identical change again.";
    }

    const edit = new vscode.WorkspaceEdit();
    const start = doc.positionAt(first);
    const end = doc.positionAt(first + oldText.length);
    edit.replace(uri, new vscode.Range(start, end), newText);

    const ok = await vscode.workspace.applyEdit(edit);
    return ok
      ? `Applied edit to ${vscode.workspace.asRelativePath(uri)}.`
      : "Error: applying the edit failed.";
  },
};