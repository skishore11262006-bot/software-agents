import * as vscode from "vscode";
import { exec } from "child_process";
import { AgentTool } from "./context";
import { assessRisk } from "./risk";

let auditChannel: vscode.OutputChannel | undefined;

function auditLog(command: string, decision: string, level: string): void {
  if (!auditChannel) {
    auditChannel = vscode.window.createOutputChannel("AI Agent Audit");
  }
  auditChannel.appendLine(
    `${new Date().toISOString()} | risk=${level} | ${decision} | ${command}`
  );
}

async function confirmWithUser(
  command: string,
  level: string,
  reasons: string[]
): Promise<boolean> {
  const riskNote = reasons.length
    ? `\n\nRisk: ${reasons.join("; ")}`
    : "";
  const label = level === "high" ? " (HIGH RISK)" : "";

  const choice = await vscode.window.showInformationMessage(
    `The AI agent wants to run${label}:\n\n${command}${riskNote}`,
    { modal: true },
    "Allow",
    "Deny"
  );
  return choice === "Allow";
}

export const runCommandTool: AgentTool = {
  name: "run_command",
  description:
    "Run a shell command in the workspace folder (e.g. 'npm test'). Requires user approval; dangerous commands are blocked automatically. Returns stdout and stderr.",
  parameters: {
    type: "object",
    properties: {
      command: {
        type: "string",
        description: "The command to execute, e.g. 'npm test'",
      },
      timeoutSeconds: {
        type: "number",
        description: "Timeout in seconds (default 30, max 120)",
      },
    },
    required: ["command"],
  },
  async execute(args) {
    const command: string = String(args.command);
    const risk = assessRisk(command);

    if (risk.level === "blocked") {
      auditLog(command, "BLOCKED", risk.level);
      return `BLOCKED by safety policy: ${risk.reasons.join(
        "; "
      )}. Suggest a safer alternative to the user instead.`;
    }

    const allowed = await confirmWithUser(
      command,
      risk.level,
      risk.reasons
    );
    auditLog(command, allowed ? "ALLOWED" : "DENIED", risk.level);

    if (!allowed) {
      return "User DENIED permission. Do not retry this command.";
    }

    const folder = vscode.workspace.workspaceFolders?.[0];
    if (!folder) {
      return "Error: no workspace folder is open.";
    }
    const cwd = folder.uri.fsPath;
    const timeout = Math.min(Number(args.timeoutSeconds ?? 30), 120) * 1000;

    return new Promise<string>((resolve) => {
      exec(
        command,
        { cwd, timeout, maxBuffer: 1024 * 1024, encoding: "utf8" },
        function (err, stdout, stderr): void {
          let out = "";
          if (stdout) out += stdout;
          if (stderr) out += (out ? "\n--- stderr ---\n" : "") + stderr;
          if (err) out += `\n--- failed: ${err.message} ---`;
          if (!out.trim()) out = "(command produced no output)";
          auditLog(command, err ? "FAILED" : "OK", risk.level);
          resolve(out.slice(-8000));
        }
      );
    });
  },
};