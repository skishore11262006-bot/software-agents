import { contextTools, AgentTool } from "./context";
import { getErrorsTool } from "./diagnostics";
import { runCommandTool } from "./testing";
import { proposeEditTool } from "./patcher";

export const allTools: AgentTool[] = [
  ...contextTools,
  getErrorsTool,
  runCommandTool,
  proposeEditTool,
];