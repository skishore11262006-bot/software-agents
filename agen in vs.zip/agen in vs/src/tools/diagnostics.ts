import * as vscode from "vscode";
import { AgentTool } from "./context";

export const getErrorsTool: AgentTool = {
  name: "get_errors",
  description:
    "Get current errors and warnings from the VS Code Problems panel (file, line, severity, message)",
  parameters: {
    type: "object",
    properties: {},
    required: [],
  },
  async execute() {
    const lines: string[] = [];

    for (const [uri, diagnostics] of vscode.languages.getDiagnostics()) {
      if (diagnostics.length === 0) {
        continue;
      }
      const rel = vscode.workspace.asRelativePath(uri);

      for (const d of diagnostics) {
        const line = d.range.start.line + 1;
        const col = d.range.start.character + 1;
        const severity =
          d.severity === vscode.DiagnosticSeverity.Error
            ? "error"
            : d.severity === vscode.DiagnosticSeverity.Warning
              ? "warning"
              : "info";

        lines.push(`${rel}:${line}:${col} [${severity}] ${d.message}`);

        if (lines.length >= 100) {
          break;
        }
      }

      if (lines.length >= 100) {
        break;
      }
    }

    return lines.length
      ? lines.join("\n")
      : "No problems found in the workspace.";
  },
};