export type RiskLevel = "low" | "high" | "blocked";

export interface RiskAssessment {
  level: RiskLevel;
  reasons: string[];
}

interface Rule {
  pattern: RegExp;
  reason: string;
}

const BLOCKED_RULES: Rule[] = [
  {
    pattern: /\brm\s+(-[a-z]+\s+)*-\w*r\w*f\w*\s+(\/|[a-z]:\\?$)/i,
    reason: "recursive delete of root or a whole drive",
  },
  { pattern: /\bmkfs\b/i, reason: "formats a filesystem" },
  { pattern: /\bformat\s+[a-z]:/i, reason: "formats a drive" },
  { pattern: /:\(\)\s*\{\s*:\|:\s*&\s*\}\s*;?/, reason: "fork bomb" },
  {
    pattern: /\|\s*(sudo\s+)?(ba|z|k)?sh\b/,
    reason: "pipes content directly into a shell",
  },
  { pattern: />\s*\/dev\/sd[a-z]/, reason: "writes to a raw disk device" },
  {
    pattern: /\bdel\s+\/[a-z]*\s*[a-z]:\\?$/i,
    reason: "deletes an entire drive",
  },
];

const HIGH_RULES: Rule[] = [
  { pattern: /\brm\s+.*-rf\b/i, reason: "recursive forced delete" },
  {
    pattern: /git\s+push\s+(.*\s)?--force\b/i,
    reason: "force push overwrites remote history",
  },
  { pattern: /\bsudo\b/, reason: "runs with elevated privileges" },
  {
    pattern: /git\s+reset\s+--hard\b/,
    reason: "discards local changes permanently",
  },
  {
    pattern: /\b(chmod|chown)\s+-R\b/i,
    reason: "recursive permission changes",
  },
  { pattern: /\bnpm\s+(publish|unpublish)\b/, reason: "publishes a package" },
  {
    pattern: /\bdel\s+\/[a-z]*[sq]/i,
    reason: "recursive forced delete (Windows)",
  },
  {
    pattern: /\b(shutdown|poweroff)\b/i,
    reason: "shuts down the machine",
  },
];

function reasonsFor(rules: Rule[], command: string): string[] {
  return rules
    .filter((r) => r.pattern.test(command))
    .map((r) => r.reason);
}

export function assessRisk(command: string): RiskAssessment {
  const blocked = reasonsFor(BLOCKED_RULES, command);
  if (blocked.length > 0) {
    return { level: "blocked", reasons: blocked };
  }
  const high = reasonsFor(HIGH_RULES, command);
  if (high.length > 0) {
    return { level: "high", reasons: high };
  }
  return { level: "low", reasons: [] };
}